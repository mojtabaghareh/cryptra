# Cryptra

Cryptra monorepo structure for Telegram Bot, Telegram Mini App, Web, Admin Panel, shared packages, services, database, infrastructure and documentation.

This archive contains the complete project structure. Source implementations and production configuration can be added incrementally without changing the architecture.
