# Cryptra

Telegram-native crypto trading platform (Mini App + Bot)  
Focus: Swap, Perpetuals, Wallet, XP/Levels, Referral, Fees

## Stack

- **Monorepo**: pnpm + Turborepo
- **Language**: TypeScript (strict)
- **Runtime**: Node.js 20+
- **Database**: PostgreSQL + Prisma
- **Cache / Queue**: Redis + BullMQ
- **Frontend**: Telegram Mini App
- **Observability**: Pino + Sentry + Prometheus metrics + Telegram alerts

## Project Structure

```
cryptra/
├── apps/
│   ├── mini-app/       # Telegram Mini App
│   ├── bot/            # Telegram Bot
│   └── admin/          # Admin panel + live monitoring dashboard
├── packages/
│   ├── core/           # Types, Interfaces, Enums, Errors, Events
│   ├── config/         # Central configuration
│   ├── database/       # Prisma schema + repositories
│   ├── security/       # Validation, RBAC, Rate Limit, Audit, Circuit Breaker
│   ├── monitoring/     # Logging, Sentry, Metrics, Health, Alerts
│   ├── queue/          # Background jobs
│   ├── auth/           # Telegram + Wallet auth
│   ├── wallet/         # Wallet abstraction + adapters
│   ├── fees/
│   ├── xp/
│   ├── levels/
│   ├── referral/
│   ├── rewards/
│   ├── achievements/
│   ├── swap/
│   ├── perp/
│   ├── market-data/
│   ├── portfolio/
│   ├── analytics/
│   └── notification/
```

## Getting Started

```bash
# Install dependencies
pnpm install

# Copy environment
cp .env.example .env

# Run in development
pnpm dev
```

## Scalability & Observability

- Advanced Rate Limiting + Circuit Breaker
- Connection pooling + Redis caching
- Structured logging (Pino)
- Error tracking (Sentry)
- Metrics (Prometheus)
- Real-time Telegram alerts for critical issues
- Health check endpoints
- Ready for horizontal scaling

## License

Private
