// Basic ESLint flat config placeholder
// Will be expanded in later phases

export default [
  {
    ignores: ["**/node_modules/**", "**/dist/**", "**/.turbo/**"],
  },
];
